from django.shortcuts import render
from django.http import HttpResponse
from .models import PlcInfo
from .forms import HoldRegForm
from django.views.generic import DetailView , UpdateView
import easymodbus.modbusClient
import datetime
import time

holding_registers = [0,0,0,0,0,0,2,0,0,0]
input_registers = [0,2,0,20,0,0,0,0,0,0]	
def index(request):	
	ip = "192.168.0.10"
	client = easymodbus.modbusClient.ModbusClient(ip,502)
	client.connect()
	if(client.is_connected()):
		holding_registers = client.read_holdingregisters(0, 5)
		input_registers = client.read_inputregisters(0, 5) 
	registers = zip(holding_registers,input_registers)
	if request.method == "POST":
		for i in range(5):
			regID = 'holdReg'+(str(i+1))
			data = HoldRegForm(request.POST).data[regID]
			if(data != "NaN"):
				data = int(data)
				#holding_registers[i] = data
				client.write_single_register(i,data)
		client.close()
		return render(request,'main/index.html',{'holdReg':holding_registers,'inpReg':input_registers,'form':HoldRegForm})
	else:
		client.close()
		return render(request,'main/index.html',{'holdReg':holding_registers,'inpReg':input_registers,'form':HoldRegForm})
