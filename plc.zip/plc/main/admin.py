from django.contrib import admin
from .models import PlcInfo
admin.site.register(PlcInfo)
