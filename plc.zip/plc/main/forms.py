from .models import PlcInfo
from django.forms import ModelForm , TextInput

class HoldRegForm(ModelForm):
	class Meta:
		model = PlcInfo
		fields = ["holdReg1","holdReg2","holdReg3","holdReg4","holdReg5"]
		widgets = {
			"holdReg1": TextInput(attrs={
			'value':'NaN',
			'name':'holdReg1',
			}),
			"holdReg2": TextInput(attrs={
			'value':'NaN',
			'name':'holdReg2',
			}),
			"holdReg3": TextInput(attrs={
			'value':'NaN',
			'name':'holdReg3',
			}),
			"holdReg4": TextInput(attrs={
			'value':'NaN',
			'name':'holdReg4',
			}),
			"holdReg5": TextInput(attrs={
			'value':'NaN',
			'name':'holdReg5',
			})
			}

