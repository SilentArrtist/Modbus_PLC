from django.db import models


class PlcInfo(models.Model):
	holdReg1 = models.IntegerField()
	holdReg2 = models.IntegerField()
	holdReg3 = models.IntegerField()
	holdReg4 = models.IntegerField()
	holdReg5 = models.IntegerField()
